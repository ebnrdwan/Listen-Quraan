package com.example.android.playona;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    ActionBarDrawerToggle toggle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(MainActivity.this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        final Button mainButton = (Button)findViewById(R.id.mainstart);
        mainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(MainActivity.this,Home.class);
                startActivity(mainIntent);
            }
        });

        ImageButton MainButton = (ImageButton)findViewById(R.id.mainhelp);
   MainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast = Toast.makeText(MainActivity.this, "this screen is the entrance for the app, you still can use the left Drwaer navigation for easier access of different screens", Toast.LENGTH_LONG);
                toast.show();

            }
        });
    }

    //if any item selected from navigatoin drawer
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (toggle.onOptionsItemSelected(item))
            return true;
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        TextView text = (TextView) findViewById(R.id.text1);
        switch (item.getItemId()) {
            case R.id.nav_menu1:
                Intent HomeIntent = new Intent(MainActivity.this, Home.class);
                startActivity(HomeIntent);
                break;
            case R.id.nav_menu2:
                Intent SheikhIntent = new Intent(MainActivity.this, Sheikh.class);
                startActivity(SheikhIntent);
                break;
            case R.id.nav_menu3:
                Intent SearchIntent = new Intent(MainActivity.this, Search.class);
                startActivity(SearchIntent);
                break;
            case R.id.nav_menu4:
         Toast toast =  Toast.makeText(MainActivity.this, "not available yet", Toast.LENGTH_LONG); toast.show();
                break;

            case R.id.setting:
                Toast toastSitting =  Toast.makeText(MainActivity.this, "sorry this also not available yet", Toast.LENGTH_LONG); toastSitting.show();
                break;
            case R.id.share:
                Toast toastShare =  Toast.makeText(MainActivity.this, "ugh!  not available yet and stop freeking your slef!", Toast.LENGTH_LONG); toastShare.show();
                break;
        }

        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawerLayout.isDrawerOpen(GravityCompat.START))
            drawerLayout.closeDrawer(GravityCompat.START);
        return false;
    }
}
