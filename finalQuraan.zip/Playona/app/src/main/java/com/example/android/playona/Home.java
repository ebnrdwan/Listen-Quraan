package com.example.android.playona;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class Home extends AppCompatActivity {

    MediaPlayer Quraan ;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        final ImageButton add = (ImageButton)findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,Search.class);
                startActivity(intent);


            }
        });
      ImageButton helpButton = (ImageButton)findViewById(R.id.help);
        helpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast = Toast.makeText(Home.this, "this screen for current playing file \n you can play, puse and stop any Quraan file you wanna within your storage", Toast.LENGTH_SHORT);
                toast.show();

            }
        });

        Button puse = (Button)findViewById(R.id.puse);
        puse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Quraan.pause();
              position = Quraan.getCurrentPosition();


            }
        });

        Button play = (Button)findViewById(R.id.play);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Quraan==null){
                Quraan = MediaPlayer.create(Home.this,R.raw.quraan);
                Quraan.start();}
                else if (!Quraan.isPlaying()) {
                    Quraan.seekTo(position);
                    Quraan.start();
                }

            }
        });

        Button stop = (Button)findViewById(R.id.stop);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  Quraan.release();
                  Quraan=null;
            }
        });

    }
}
