package com.example.android.playona;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class Search extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);


        ImageButton searchButton = (ImageButton)findViewById(R.id.searchhelp);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast = Toast.makeText(Search.this, "this screen is seach within your sdcard about audio files\n please press long click for moving to main screen", Toast.LENGTH_LONG);
                toast.show();

            }
        });
        searchButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent searchIntent = new Intent(Search.this, MainActivity.class);
                startActivity(searchIntent);
                return false;
            }
        });
    }
}
