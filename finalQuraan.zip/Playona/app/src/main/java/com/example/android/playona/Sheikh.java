package com.example.android.playona;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class Sheikh extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sheikh);
        ImageButton sheikhhelp = (ImageButton)findViewById(R.id.selecthelp);
        sheikhhelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast = Toast.makeText(Sheikh.this, "this screen for selecting your Sheikh who recite the holy Quraan", Toast.LENGTH_SHORT);
                toast.show();

            }
        });

        ImageButton listButton = (ImageButton)findViewById(R.id.currentlist);
        listButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sheikhIntent = new Intent(Sheikh.this, Search.class);
                startActivity(sheikhIntent);
            }
        });
    }
}
